package com.algoDomain.controller;

import java.util.List;  
import org.springframework.beans.factory.annotation.*;  
import org.springframework.web.bind.annotation.*;  
import com.algoDomain.model.*;
import com.algoDomain.service.ProductService;
import com.algoDomain.model.*;
import com.algoDomain.repository.*;

@RestController
public class ProductController {

	@Autowired
	ProductService productService;
	
	@GetMapping("/product")  
	private List<Product> getAllProduct()   
	{  
	return productService.getAllProduct();  
	}  
	
	@GetMapping("/product/{productid}")  
	private Product getProduct(@PathVariable("productid") int productid)   
	{  
	return productService.getProductById(productid);  
	}  
	//creating a delete mapping that deletes a specified product  
	@DeleteMapping("/product/{productid}")  
	private void deleteProduct(@PathVariable("productid") int productid)   
	{  
	productService.delete(productid);  
	}  
	
	@PostMapping("/product")  
	private int saveProduct(@RequestBody Product product)   
	{  
	productService.saveOrUpdate(product);  
	return product.getProduct_id();  
	}  
	//creating put mapping that updates the book detail   
	@PutMapping("/product")  
	private Product update(@RequestBody Product product)   
	{  
	productService.saveOrUpdate(product);  
	return product;  
	}  
}
