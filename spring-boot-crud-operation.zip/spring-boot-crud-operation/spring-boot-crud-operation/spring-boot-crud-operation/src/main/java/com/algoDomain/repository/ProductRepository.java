package com.algoDomain.repository;

	import org.springframework.data.repository.CrudRepository;  
	import com.algoDomain.model.*;  
	//repository that extends CrudRepository  
	public interface ProductRepository extends CrudRepository<Product, Integer>  
	{  
	}  

