package com.algoDomain.model;

public enum productCategory {

	Electronics,HomeAppliances,Clothing,Furniture
}
